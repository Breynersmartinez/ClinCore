import React from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider } from './context/AuthContext'
import { AlertProvider } from './components/ui/Alert'
import PrivateRoute from './components/Layout/PrivateRoute'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import UsuariosPage from './pages/usuarios/UsuariosPage'
import RolesPage from './pages/roles/RolesPage'
import ConsultoriosPage from './pages/consultorios/ConsultoriosPage'
import CitasPage from './pages/citas/CitasPage'

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AlertProvider>
          <Routes>
            {/* Public */}
            <Route path="/login" element={<Login />} />

            {/* Private */}
            <Route element={<PrivateRoute />}>
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/usuarios" element={<UsuariosPage />} />
              <Route path="/roles" element={<RolesPage />} />
              <Route path="/consultorios" element={<ConsultoriosPage />} />
              <Route path="/citas" element={<CitasPage />} />
            </Route>

            {/* Redirect */}
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
            <Route path="*" element={<Navigate to="/dashboard" replace />} />
          </Routes>
        </AlertProvider>
      </AuthProvider>
    </BrowserRouter>
  )
}

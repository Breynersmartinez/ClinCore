import React, { createContext, useState, useEffect, useCallback } from 'react'
import { login as loginApi } from '../api/authApi'
import { buildPermisosSet } from '../utils/permisos'

export const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try {
      const stored = localStorage.getItem('user')
      return stored ? JSON.parse(stored) : null
    } catch {
      return null
    }
  })
  const [accessToken, setAccessToken] = useState(
    () => localStorage.getItem('accessToken') || null
  )
  const [loading, setLoading] = useState(false)

  // Listen for forced logout from axios interceptor
  useEffect(() => {
    const handler = () => logout()
    window.addEventListener('auth:logout', handler)
    return () => window.removeEventListener('auth:logout', handler)
  }, [])

  const login = useCallback(async (username, password) => {
    setLoading(true)
    try {
      const res = await loginApi({ username, password })
      const { accessToken, refreshToken, roles, permisos } = res.data.data

      const userData = {
        username,
        roles: roles || [],
        permisos: permisos || [],
        permisosSet: [...buildPermisosSet(permisos || [])],
      }

      localStorage.setItem('accessToken', accessToken)
      if (refreshToken) localStorage.setItem('refreshToken', refreshToken)
      localStorage.setItem('user', JSON.stringify(userData))

      setAccessToken(accessToken)
      setUser(userData)
      return { success: true }
    } catch (error) {
      const message =
        error.response?.data?.message || 'Credenciales inválidas'
      return { success: false, message }
    } finally {
      setLoading(false)
    }
  }, [])

  const logout = useCallback(() => {
    localStorage.removeItem('accessToken')
    localStorage.removeItem('refreshToken')
    localStorage.removeItem('user')
    setAccessToken(null)
    setUser(null)
  }, [])

  const hasPermiso = useCallback(
    (key) => {
      if (!user?.permisosSet) return false
      return user.permisosSet.includes(key)
    },
    [user]
  )

  const hasRole = useCallback(
    (role) => {
      if (!user?.roles) return false
      return user.roles.includes(role)
    },
    [user]
  )

  const value = {
    user,
    accessToken,
    loading,
    isAuthenticated: !!accessToken,
    login,
    logout,
    hasPermiso,
    hasRole,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}
